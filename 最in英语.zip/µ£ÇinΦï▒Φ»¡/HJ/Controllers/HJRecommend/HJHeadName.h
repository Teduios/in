//
//  HJHeadName.h
//  HJ
//
//  Created by tarena6 on 16/2/19.
//  Copyright © 2016年 YH. All rights reserved.
//

#ifndef HJHeadName_h
#define HJHeadName_h
enum HJHeadName{
    HJHeadNameHeadline = 0,
    HJHeadNameListen,
    HJHeadNameSpoken,
    HJHeadNameVocabulary,
    HJHeadNameDrama,
    HJHeadNameCareer

};




#endif /* HJHeadName_h */

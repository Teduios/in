//
//  HJRecommendViewController.h
//  HJ
//
//  Created by tarena6 on 16/2/17.
//  Copyright © 2016年 YH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HJRecommendViewController : UIViewController
@property(nonatomic,strong)NSString *urlTitle;
@property(nonatomic,strong)NSString *idStr;
@property(nonatomic,strong)NSString *lefNaviItemName;
@end

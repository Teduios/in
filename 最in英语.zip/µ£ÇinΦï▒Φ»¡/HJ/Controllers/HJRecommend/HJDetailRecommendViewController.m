//
//  HJDetailRecommendViewController.m
//  HJ
//
//  Created by tarena6 on 16/2/13.
//  Copyright © 2016年 YH. All rights reserved.
//

#import "HJDetailRecommendViewController.h"
#import "Masonry.h"
#import <WebKit/WebKit.h>
#import "AFNetworking.h"
#import "HJNetworkManager.h"
#import "HJDataManager.h"
#import "MBProgressHUD.h"

const NSString *str = @"http://www.hjenglish.com/api/api_IOSNews.ashx?op=GetContent&contentID=";
@interface HJDetailRecommendViewController ()<UIWebViewDelegate>
{
    
    NSInteger _num;
}


@property(nonatomic,strong)UIWebView *webView;//WKWebView *webView;
@end

@implementation HJDetailRecommendViewController
-(UIWebView *)webView{
    if (!_webView) {
        _webView = [UIWebView new];
         _webView.delegate = self;
        _webView.backgroundColor = [UIColor whiteColor];
    }
    return _webView;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.webView];
    [self.webView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.top.bottom.mas_equalTo(0);
    }];
    NSString *urlStr = [NSString stringWithFormat:@"%@%@",str,self.contentID];
    [HJNetworkManager sendGetRequestWithUrl:urlStr parameters:nil success:^(id responseObject) {

        NSString *str = responseObject[@"Value"][0][@"Content"];
        NSString *headLabelTest = responseObject[@"Value"][0][@"Title"];
        NSString *timeLabelTest = responseObject[@"Value"][0][@"LastUpdateTime"];
        NSString *contentStr = [NSString stringWithFormat:@"<html><head> <style type='text/css'> div{font-size:15px;}img{width:300;} </style> </head> <body><h3>%@</h3><h5>%@</h5>%@</html>",headLabelTest,timeLabelTest,str];
        [self.webView loadHTMLString:contentStr baseURL:nil];
    } failure:^(NSError *error) {
        MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        hud.mode = MBProgressHUDModeText;
        hud.labelText = @"网络错误，请检查您的网络";
        [hud hide:YES afterDelay:3];
    }];
}

#pragma mark UIWebViewdelegate


-(BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
//    NSLog(@"url %@",request.URL.absoluteString);
    if ([request.URL.absoluteString hasPrefix:@"http"]) {
        [[UIApplication sharedApplication]openURL:request.URL];
        return NO;
    }else
    {
        return YES;
    }
}



@end

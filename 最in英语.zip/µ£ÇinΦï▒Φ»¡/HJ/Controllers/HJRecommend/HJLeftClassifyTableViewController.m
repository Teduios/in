//
//  HJLeftClassifyTableViewController.m
//  HJ
//
//  Created by tarena6 on 16/2/11.
//  Copyright © 2016年 YH. All rights reserved.
//


#import "HJLeftClassifyTableViewController.h"

#import "HJRecommendViewController.h"


@interface HJLeftClassifyTableViewController ()
@property(nonatomic,strong)NSArray *ClassifyArray;
@property(nonatomic,strong)NSArray *ImageNameArray;
@property(nonatomic,strong)NSString *recommendItemName;
//@property(nonatomic,strong)NSArray *urlTitleArray;
@property(nonatomic,strong)NSArray *idArray;
@property(nonatomic,strong)NSString *idStr;


@end

@implementation HJLeftClassifyTableViewController

-(NSArray *)ClassifyArray{
    if (!_ClassifyArray) {
        _ClassifyArray = @[@"实用英语",@"娱乐英语",@"考试英语",@"基础英语"];
    }
    return _ClassifyArray;
}
-(NSArray *)ImageNameArray{
    if (!_ImageNameArray) {
        _ImageNameArray =@[@"practicalIcon",@"entIcon",@"testIcon",@"basicIcon"];
    }
    return _ImageNameArray;
}
/**
 先排推荐
 头条；听力；美剧；职场；口语；词汇
 再排分类
 实用英语；娱乐英语；考试英语；基础英语
 */

//-(NSArray *)urlTitleArray{
//    if (!_urlTitleArray) {
//        _urlTitleArray = @[@"GetHotListWithColumns",@"GetListenListWithTime",@"GetListByTagWithTime",@"GetListByChildCateWithTime",@"GetListByChildCateWithTime",@"GetListByChildCateWithTime",@"GetListByParentCateWithTime",@"GetListByParentCateWithTime",@"GetListByParentCateWithTime",@"GetListByParentCateWithTime"];
//    }
//    return _urlTitleArray;
//}
-(NSArray *)idArray{
    if (!_idArray) {
        _idArray =@[@"cateID=1040",@"cateID=1070",@"cateID=1020",@"cateID=1010"];
    }
    return _idArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    
}

#pragma mark - Table view data source



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

   return self.ClassifyArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ClassifyCell" forIndexPath:indexPath];
    cell.textLabel.text = self.ClassifyArray[indexPath.row];

    cell.imageView.image = [UIImage imageNamed:self.ImageNameArray[indexPath.row]];
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    self.recommendItemName = self.ClassifyArray[indexPath.row];
    self.idStr = self.idArray[indexPath.row];
    
    
    [self performSegueWithIdentifier:@"GoBackToRcommendSegue" sender:self.idStr];
}
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    HJRecommendViewController *destController = segue.destinationViewController;
    destController.urlTitle =@"GetListByParentCateWithTime";
    destController.idStr =self.idStr;
    destController.lefNaviItemName = self.recommendItemName;
    
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

//
//  HJRecommendViewController.m
//  HJ
//
//  Created by tarena6 on 16/2/17.
//  Copyright © 2016年 YH. All rights reserved.
//

#import "HJRecommendViewController.h"
#import "HJTableViewCell.h"
//#import "RESideMenu.h"
#import "HJLeftClassifyTableViewController.h"
#import "HJRightMoreTableViewController.h"
#import "HJDetailRecommendViewController.h"
#import "HJRecommend.h"
#import "HJDataManager.h"
#import "HJNetworkManager.h"
#import "MJRefresh.h"
#import "MBProgressHUD.h"
#import "HJHeadName.h"
//#import "HJRefresh.h"

//typedef void(^getUrlBlock)(NSString *url);

@interface HJRecommendViewController ()<UITableViewDataSource,UITableViewDelegate,MBProgressHUDDelegate>

@property (weak, nonatomic) IBOutlet UIView *titleView;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property(nonatomic,strong)NSArray *recommendArray;

@property(nonatomic,strong)UIButton *button;
@property (weak, nonatomic) IBOutlet UIButton *headButton;

@property(nonatomic,strong)NSArray *urlTitleArray;
@property(nonatomic,strong)NSArray *idAndTagArray;
@property(nonatomic,strong)NSString *urlStr;
@property(nonatomic,strong)NSString *urlName;
@property(nonatomic,strong)NSString *urlIdAndTag;
@property(nonatomic,assign)NSInteger urlCount;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *titleViewHeightConstraint;

@property(nonatomic,strong) MBProgressHUD *hudP;
- (IBAction)buttonsClick:(id)sender;
- (IBAction)exitButtonClick:(id)sender;

@end

@implementation HJRecommendViewController

/** GetListByChildCateWithTime   cateID=1044     urlTitle  idAndTag*/
/**
 先排推荐
 头条；听力；美剧；职场；口语；词汇
 再排分类
 实用英语；娱乐英语；考试英语；基础英语
 */

-(NSArray *)urlTitleArray{
    if (!_urlTitleArray) {
        _urlTitleArray = @[@"GetHotListWithColumns",@"GetListenListWithTime",@"GetListByChildCateWithTime",@"GetListByChildCateWithTime",@"GetListByTagWithTime",@"GetListByChildCateWithTime"];
    }
    return _urlTitleArray;
}
-(NSArray *)idAndTagArray{
    if (!_idAndTagArray) {
        _idAndTagArray =@[@"",@"",@"cateID=1042",@"cateID=1048",@"tag=%E7%BE%8E%E5%89%A7%E7%AC%94%E8%AE%B0",@"cateID=1044"];
    }
    return _idAndTagArray;
}


- (void)viewDidLoad {
    [super viewDidLoad];

    [self.tableView registerNib:[UINib nibWithNibName:@"HJTableViewCell" bundle:nil] forCellReuseIdentifier:@"cell"];
    self.button = self.headButton;
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    if (self.lefNaviItemName) {
        self.navigationItem.leftBarButtonItem.title = self.lefNaviItemName;
        self.titleView.hidden = YES;
        self.titleViewHeightConstraint.constant = 0;
    }
    
    self.urlCount = 10;
    [self creatRefreshControlAndSendRequest];
   
}

-(void)creatRefreshControlAndSendRequest{
    MJRefreshNormalHeader *header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(sendRequestToServer)];
    header.lastUpdatedTimeLabel.hidden = NO;
    [header beginRefreshing];
    self.tableView.mj_header = header;

    MJRefreshBackNormalFooter *footer = [MJRefreshBackNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(sendGetMoreData)];
    [footer beginRefreshing];
    self.tableView.mj_footer = footer;
    
}
-(void)sendRequestToServer{
    /**
     @property(nonatomic,strong)NSString *urlTitle;
     @property(nonatomic,strong)NSString *idStr;
     
     */
  if (self.urlTitle) {
      
        self.urlName = self.urlTitle;
      
        self.urlIdAndTag = self.idStr;

        [self sendRequest];

  }else{
      self.urlName = self.urlTitleArray[self.button.tag];
      self.urlIdAndTag = self.idAndTagArray[self.button.tag];
      
      
     
      [self sendRequest];
  }
    
    

    
}

-(void)sendRequest{
    self.urlStr = [NSString stringWithFormat:@"http://www.hjenglish.com/api/api_IOSNews.ashx?op=%@&langs=en&count=%ld&%@&endTime=%@%@&beginTime=1970-01-01%@",self.urlName,(long)self.urlCount,self.urlIdAndTag,[[NSString stringWithFormat:@"%@",[NSDate date]] substringToIndex:10],@"%2013:36:07",@"%2008:00:00"];
    [HJNetworkManager sendGetRequestWithUrl:self.urlStr parameters:nil success:^(id responseObject) {
        self.recommendArray = [HJDataManager getAllReconmmandData:responseObject];
        [self.tableView reloadData];
      
        [self.tableView.mj_header endRefreshing];
    } failure:^(NSError *error) {
        [self networkRemind];
        [self.tableView.mj_header endRefreshing];
    }];


}
//等会
-(void)sendGetMoreData{
    self.urlCount += 10;
    self.urlStr = [NSString stringWithFormat:@"http://www.hjenglish.com/api/api_IOSNews.ashx?op=%@&langs=en&count=%ld&%@&endTime=%@%@&beginTime=1970-01-01%@",self.urlName,(long)self.urlCount,self.urlIdAndTag,[[NSString stringWithFormat:@"%@",[NSDate date]] substringToIndex:10],@"%2013:36:07",@"%2008:00:00"];
    [HJNetworkManager sendGetRequestWithUrl:self.urlStr parameters:nil success:^(id responseObject) {
        self.recommendArray = [HJDataManager getAllReconmmandData:responseObject];
        [self.tableView reloadData];
        
        [self.tableView.mj_footer endRefreshing];
    } failure:^(NSError *error) {
        [self networkRemind];
        [self.tableView.mj_footer endRefreshing];
    }];
   
}

- (void) networkRemind{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.mode = MBProgressHUDModeText;
    hud.labelText = @"网络繁忙，请稍后再试";
    hud.margin = 10;
    [hud hide:YES afterDelay:3];
}

#pragma mark - Table view data source


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
   
    return  self.recommendArray.count;
    
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    HJTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    
        HJRecommend *recommend = self.recommendArray[indexPath.row];
        cell.recommend = recommend;
    
   
    
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    HJDetailRecommendViewController *detailRecomendViewController = [HJDetailRecommendViewController new];
    
    HJRecommend *recommend = self.recommendArray[indexPath.row];
    detailRecomendViewController.contentID = recommend.ContentID;
   
    MBProgressHUD *hud = [[MBProgressHUD alloc]initWithView:self.navigationController.view];
    [self.navigationController.view addSubview:hud];
    hud.delegate = self;
    [hud showWhileExecuting:@selector(myTask) onTarget:self withObject:nil animated:YES];
    
    
    [self.navigationController pushViewController:detailRecomendViewController animated:YES];
}

- (void)myTask {
    sleep(0.9);
}

- (IBAction)buttonsClick:(id)sender {
   
    UIButton *senderButton = (UIButton *)sender;
    if (self.button == senderButton) {
        return;
    }
    senderButton.selected = YES;
    self.button.selected = NO;
    self.button = senderButton;
    
    self.urlName = self.urlTitleArray[senderButton.tag];
    self.urlIdAndTag = self.idAndTagArray[senderButton.tag];
   
    self.urlCount = 10;
    [self sendRequest];
  
  }

- (IBAction)exitButtonClick:(id)sender {
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"LoginAndRegister" bundle:nil];
    UIViewController *vc = storyboard.instantiateInitialViewController;
    [UIApplication sharedApplication].keyWindow.rootViewController = vc;
    
}
#pragma mark - MBProgressHUDDelegate
- (void)hudWasHidden:(MBProgressHUD *)hud {
   [self.hudP removeFromSuperview];
    self.hudP = nil;
}

- (void)viewDidUnload {
    //[self setButtons:nil];
    
    
    
    [super viewDidUnload];
}
@end

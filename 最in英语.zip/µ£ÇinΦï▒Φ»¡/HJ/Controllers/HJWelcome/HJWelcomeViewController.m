//
//  HJWelcomeViewController.m
//  HJ
//
//  Created by tarena6 on 16/2/27.
//  Copyright © 2016年 YH. All rights reserved.
//

#import "HJWelcomeViewController.h"
#import "Masonry.h"
#import "HJTabBarController.h"

@interface HJWelcomeViewController () <UIScrollViewDelegate>
@property(nonatomic,assign)NSInteger imageCount;
@property(nonatomic,strong)UIScrollView *scrollView;
@property(nonatomic,strong)UIPageControl *pageControl;

@end

@implementation HJWelcomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.imageCount = 3;
    
    [self configScrollView];
    
    [self configPageControllerView];
    
}

-(void)configScrollView{
    UIScrollView *scrollView = [[UIScrollView alloc]init];
    self.scrollView = scrollView;
    scrollView.delegate = self;
    scrollView.frame = SCREEN_BOUNDS;
    scrollView.contentSize = CGSizeMake(self.view.bounds.size.width*self.imageCount, self.view.bounds.size.height);
    for (int i = 0; i < self.imageCount; i++) {
        UIImageView *imageView = [[UIImageView alloc]init];
        imageView.frame = CGRectMake(i*self.view.bounds.size.width, 0, self.view.bounds.size.width, self.view.bounds.size.height);
        
        NSString * imageName = [NSString stringWithFormat:@"%@%d",@"welcome",i+1];
        imageView.image = [UIImage imageNamed:imageName];
        [scrollView addSubview:imageView];
//        [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.top.bottom.mas_equalTo(0);
//            make.left.mas_equalTo(i*self.view.bounds.size.width);
//            make.width.mas_equalTo(self.view.bounds.size.width);
//        }];
            if (i == 2) {
                [self configEnterButton:imageView];
        }
    }
    
    scrollView.pagingEnabled = YES;
    scrollView.bounces = NO;
    [self.view addSubview:scrollView];
   }

-(void)configEnterButton:(UIImageView *)imageView{
    imageView.userInteractionEnabled = YES;
    
    UIButton *button = [[UIButton alloc]init];
    
    button.frame = SCREEN_BOUNDS;
    [button addTarget:self action:@selector(enterApp) forControlEvents:UIControlEventTouchUpInside];
   
    [imageView addSubview:button];

    
}
-(void)enterApp{
  
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    HJTabBarController *MyTabBarController = [storyboard instantiateViewControllerWithIdentifier:@"MyTabBarControllerSegue"];
    [self.navigationController pushViewController:MyTabBarController animated:YES];
    [UIApplication sharedApplication].keyWindow.rootViewController = storyboard.instantiateInitialViewController;
    
}

-(void)configPageControllerView{
    UIPageControl *pageControl = [[UIPageControl alloc]init];
    self.pageControl = pageControl;
    pageControl.frame = CGRectMake(0, self.view.bounds.size.height-80, self.view.bounds.size.width, 40);
    pageControl.numberOfPages = 3;
    pageControl.pageIndicatorTintColor = [UIColor whiteColor];
    pageControl.currentPageIndicatorTintColor = [UIColor greenColor];
    pageControl.userInteractionEnabled = NO;
    [self.view addSubview:pageControl];
}

#pragma mark - UIScrollViewDelegate
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    CGPoint offset = scrollView.contentOffset;
    self.pageControl.currentPage = round(offset.x/scrollView.bounds.size.width);
    
}

@end

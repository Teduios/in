//
//  HJTabBarController.m
//  HJ
//
//  Created by tarena6 on 16/2/27.
//  Copyright © 2016年 YH. All rights reserved.
//

#import "HJTabBarController.h"

@implementation HJTabBarController

@end

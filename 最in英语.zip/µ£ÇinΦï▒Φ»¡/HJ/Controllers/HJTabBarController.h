//
//  HJTabBarController.h
//  HJ
//
//  Created by tarena6 on 16/2/27.
//  Copyright © 2016年 YH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HJTabBarController : UITabBarController

@end

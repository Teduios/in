//
//  HJDetailBoxViewController.m
//  HJ
//
//  Created by tarena6 on 16/2/13.
//  Copyright © 2016年 YH. All rights reserved.
//

#import "HJDetailBoxViewController.h"
#import "HJFatherViewController.h"
#import "HJDataTheme.h"
#import "MBProgressHUD.h"
#import "Masonry.h"

@interface HJDetailBoxViewController ()<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)NSArray *themeArray;

@end

@implementation HJDetailBoxViewController
-(NSArray *)themeArray{
    if (!_themeArray) {
        _themeArray =[HJDataTheme themestableName:self.tableName];
    }
    return _themeArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    UITableView *tableView = [[UITableView alloc]initWithFrame:SCREEN_BOUNDS];
    tableView.delegate = self;
    tableView.dataSource = self;
    
    [self.view addSubview:tableView];
    [tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.top.bottom.mas_equalTo(0);
    }];
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.themeArray.count;
   
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"boxCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        HJDataTheme *theme = self.themeArray[indexPath.row];
        cell.textLabel.text = theme.headline;
        
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
   
   HJFatherViewController *chapterViewController = [HJFatherViewController new];
    HJDataTheme *dataTheme = self.themeArray[indexPath.row];
    chapterViewController.dataTheme = dataTheme;
    chapterViewController.detailImageName = [NSString stringWithFormat:@"%@%ld",self.detailImageName,(long)indexPath.row];
    
    
     [self.navigationController pushViewController:chapterViewController animated:YES];
  
}

@end

//
//  HJDataManager.h
//  HJ
//
//  Created by tarena6 on 16/2/14.
//  Copyright © 2016年 YH. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HJDetail.h"

@interface HJDataManager : NSObject
+ (NSArray *)getAllReconmmandData:(id)responseObject;
+ (HJDetail *)getAllDetailData:(id)reponseObject;
+ (NSArray *)getAllThemeData:(id)responseObject;
@end

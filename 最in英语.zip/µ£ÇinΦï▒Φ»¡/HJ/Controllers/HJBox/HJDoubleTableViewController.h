//
//  HJDoubleTableViewController.h
//  HJ
//
//  Created by tarena6 on 16/2/23.
//  Copyright © 2016年 YH. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HJDataTheme.h"


@interface HJDoubleTableViewController : UITableViewController
@property(nonatomic,strong)HJDataTheme *dataTheme;
@property(nonatomic,strong)NSString *detailImageName;

@end

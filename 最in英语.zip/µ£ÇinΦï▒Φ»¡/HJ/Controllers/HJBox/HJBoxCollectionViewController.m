//
//  HJBoxCollectionViewController.m
//  HJ
//
//  Created by tarena6 on 16/2/12.
//  Copyright © 2016年 YH. All rights reserved.
//

#import "HJBoxCollectionViewController.h"
#import "HJBoxCollectionViewCell.h"
//#import "HJDetailBoxTableViewController.h"
#import "HJDetailBoxViewController.h"


@interface HJBoxCollectionViewController ()
@property(nonatomic,strong)NSArray *bookNameArray;
@property(nonatomic,strong)NSArray *imageNameArray;
@property(nonatomic,strong)NSArray *dataTableNameArray;
@property(nonatomic,strong)NSArray *detailImageNameArray;

@end

@implementation HJBoxCollectionViewController

static NSString * const reuseIdentifier = @"Cell";
-(NSArray *)bookNameArray{
    if (!_bookNameArray) {
        _bookNameArray = @[@"双语美文",@"芒果街上的小屋",@"英语笑话",@"飞鸟集",@"名人名言",@"英语笑话 第二辑",@"多里安.格雷的画像"];
    }
    return _bookNameArray;
}
-(NSArray *)imageNameArray{
    if (!_imageNameArray) {
        _imageNameArray = @[@"MEIWEN_on",@"MANGO_on",@"XIAOHUA_on",@"FEINIAOJI_on",@"MINGYAN_on",@"XIAOHUA_2_on",@"DORIAN_on"];
    }
    return _imageNameArray;
}
-(NSArray *)dataTableNameArray{
    if (!_dataTableNameArray) {
        _dataTableNameArray = @[@"HJ_ARTICLE",@"HJ_MANGO",@"HJ_JOKE",@"HJ_BIRD",@"HJ_FAMOUSE",@"HJ_ANOTHERJOKE",@"HJ_DUOLIAN"];
    }
    return _dataTableNameArray;
}
-(NSArray *)detailImageNameArray{
    if (!_detailImageNameArray) {
        _detailImageNameArray = @[@"article_",@"mango_",@"joke_",@"bird_",@"famouse_",@"anotherjoke_",@"duolian_"];
    }
    return _detailImageNameArray;
}




- (void)viewDidLoad {
    [super viewDidLoad];
    self.collectionView.backgroundColor = [UIColor whiteColor];
//    [self.collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:reuseIdentifier];
//    
     [self.collectionView registerNib:[UINib nibWithNibName:@"HJBoxCollectionViewCell" bundle:nil] forCellWithReuseIdentifier:reuseIdentifier];
    
}



#pragma mark <UICollectionViewDataSource>

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {

    return 1;
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {

    return self.bookNameArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
   HJBoxCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];
    cell.bookImageView.image = [UIImage imageNamed:self.imageNameArray[indexPath.item]];
    cell.bookNameLabel.text = self.bookNameArray[indexPath.item];
    
   
    
    return cell;
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    HJDetailBoxViewController * detailViewController = [HJDetailBoxViewController new];
    detailViewController.tableName = self.dataTableNameArray[indexPath.item];
    detailViewController.detailImageName = self.detailImageNameArray[indexPath.item];
    [self.navigationController pushViewController:detailViewController animated:YES];
    
}
#pragma mark <UICollectionViewDelegate>

/*
// Uncomment this method to specify if the specified item should be highlighted during tracking
- (BOOL)collectionView:(UICollectionView *)collectionView shouldHighlightItemAtIndexPath:(NSIndexPath *)indexPath {
	return YES;
}
*/

/*
// Uncomment this method to specify if the specified item should be selected
- (BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}
*/

/*
// Uncomment these methods to specify if an action menu should be displayed for the specified item, and react to actions performed on the item
- (BOOL)collectionView:(UICollectionView *)collectionView shouldShowMenuForItemAtIndexPath:(NSIndexPath *)indexPath {
	return NO;
}

- (BOOL)collectionView:(UICollectionView *)collectionView canPerformAction:(SEL)action forItemAtIndexPath:(NSIndexPath *)indexPath withSender:(id)sender {
	return NO;
}

- (void)collectionView:(UICollectionView *)collectionView performAction:(SEL)action forItemAtIndexPath:(NSIndexPath *)indexPath withSender:(id)sender {
	
}
*/

@end

//
//  HJDetailBoxViewController.h
//  HJ
//
//  Created by tarena6 on 16/2/13.
//  Copyright © 2016年 YH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HJDetailBoxViewController : UIViewController
@property(nonatomic,strong)NSString *tableName;
@property(nonatomic,strong)NSString *detailImageName;
@end

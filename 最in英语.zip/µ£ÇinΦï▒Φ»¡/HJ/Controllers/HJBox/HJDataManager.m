//
//  HJDataManager.m
//  HJ
//
//  Created by tarena6 on 16/2/14.
//  Copyright © 2016年 YH. All rights reserved.
//

#import "HJDataManager.h"
#import "HJRecommend.h"
#import "HJDetail.h"
#import "HJTheme.h"


/*
 @property(nonatomic,assign)NSNumber *ContentID;
 @property(nonatomic,strong)NSString *Title;
 @property(nonatomic,strong)NSString *IconUrl;
 @property(nonatomic,strong)NSString *AutoSummary;
 */
@implementation HJDataManager
+(NSArray *)getAllReconmmandData:(id)responseObject{
    NSArray *array = responseObject[@"Value"];
    NSMutableArray *mutableArray = [NSMutableArray array];
    for (NSDictionary *dic in array) {
        HJRecommend *recommend = [HJRecommend new];
        HJLog(@"----%@",dic);
        [recommend setValuesForKeysWithDictionary:dic];

       [mutableArray addObject:recommend];
    }
    return [mutableArray copy];
}

+(HJDetail *)getAllDetailData:(id)reponseObject{
    NSArray * array = reponseObject[@"Value"];
    HJDetail *detail = [HJDetail new];
    for (NSDictionary *dic in array) {
        [detail setValuesForKeysWithDictionary:dic];
    }
    return detail;
}


+(NSArray *)getAllThemeData:(id)responseObject{
   
  
    NSMutableArray *mutableArray = [NSMutableArray array];
    for (NSDictionary *dic in responseObject[@"Value"]) {
          HJTheme *theme = [HJTheme new];
        [theme setValuesForKeysWithDictionary:dic];
        [mutableArray addObject:theme];
        HJLog(@"%@--%@",theme.Title,theme.ContentID);
        
    }
    return [mutableArray copy];
}

@end

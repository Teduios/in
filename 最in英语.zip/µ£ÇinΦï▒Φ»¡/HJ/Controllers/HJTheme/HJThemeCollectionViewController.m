//
//  HJThemeCollectionViewController.m
//  HJ
//
//  Created by tarena6 on 16/2/12.
//  Copyright © 2016年 YH. All rights reserved.
//

#import "HJThemeCollectionViewController.h"
#import "HJBoxCollectionViewCell.h"
#import "HJDetailThemeViewController.h"
@interface HJThemeCollectionViewController ()
@property(nonatomic,strong)NSArray *bookNameArray;
@property(nonatomic,strong)NSArray *urlIDArray;

@end

@implementation HJThemeCollectionViewController
-(NSArray *)bookNameArray{
    if (!_bookNameArray) {
        _bookNameArray = @[@"时间",@"托业",@"互联网教育",@"CCTalk",@"苹果报道",@"名校简介",@"英语四六级报名",@"格言警句",@"吸血鬼日记",@"生活大爆炸",@"留学",@"GRE",@"慢速英语",@"标准英语",@"CNN",@"BBC",@"公开课",@"英语牛津教材",@"动漫英语",@"考研试题",@"考研词汇"];
    }
    return _bookNameArray;
}
/**urlid有关的数组*/
-(NSArray *)urlIDArray{
    if (!_urlIDArray) {
        _urlIDArray = @[@"1006",@"991",@"970",@"963",@"914",@"872",@"835",@"833",@"732",@"730",@"709",@"708",@"670",@"669",@"666",@"664",@"493",@"492",@"328",@"160",@"159"];
    }
    return _urlIDArray;
}
static NSString * const reuseIdentifier = @"Cell";

- (void)viewDidLoad {
    [super viewDidLoad];
    self.collectionView.backgroundColor = [UIColor whiteColor];
//    [self.collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:reuseIdentifier];
    [self.collectionView registerNib:[UINib nibWithNibName:@"HJBoxCollectionViewCell" bundle:nil] forCellWithReuseIdentifier:reuseIdentifier];
}
#pragma mark <UICollectionViewDataSource>

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.bookNameArray.count;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    HJBoxCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];
    NSString *imageName = [NSString stringWithFormat:@"%ld",(long)indexPath.item];
    cell.bookImageView.image = [UIImage imageNamed:imageName];
    cell.bookNameLabel.text = self.bookNameArray[indexPath.item];
    return cell;
}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    HJDetailThemeViewController *detailThemeViewController = [HJDetailThemeViewController new];
    detailThemeViewController.urlStrID = self.urlIDArray[indexPath.item];

    [self.navigationController pushViewController:detailThemeViewController animated:YES];
}

#pragma mark <UICollectionViewDelegate>

/*
// Uncomment this method to specify if the specified item should be highlighted during tracking
- (BOOL)collectionView:(UICollectionView *)collectionView shouldHighlightItemAtIndexPath:(NSIndexPath *)indexPath {
	return YES;
}
*/

/*
// Uncomment this method to specify if the specified item should be selected
- (BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}
*/

/*
// Uncomment these methods to specify if an action menu should be displayed for the specified item, and react to actions performed on the item
- (BOOL)collectionView:(UICollectionView *)collectionView shouldShowMenuForItemAtIndexPath:(NSIndexPath *)indexPath {
	return NO;
}

- (BOOL)collectionView:(UICollectionView *)collectionView canPerformAction:(SEL)action forItemAtIndexPath:(NSIndexPath *)indexPath withSender:(id)sender {
	return NO;
}

- (void)collectionView:(UICollectionView *)collectionView performAction:(SEL)action forItemAtIndexPath:(NSIndexPath *)indexPath withSender:(id)sender {
	
}
*/

@end

//
//  HJDetailThemeViewController.m
//  HJ
//
//  Created by tarena6 on 16/2/13.
//  Copyright © 2016年 YH. All rights reserved.
//

#import "HJDetailThemeViewController.h"
#import "HJSubDetailViewController.h"
#import "Masonry.h"
#import "HJThemeTableViewCell.h"
#import "HJNetworkManager.h"
#import "HJDataManager.h"
#import "HJTheme.h"
#import "MBProgressHUD.h"
#import "HJDetail.h"
#import "MJRefresh.h"


@interface HJDetailThemeViewController ()<UITableViewDelegate,UITableViewDataSource,MBProgressHUDDelegate>
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)NSString *urlStr;
@property(nonatomic,assign)NSInteger count;
@property(nonatomic,strong)NSArray *themeArray;
@property(nonatomic,strong)NSArray *bookChapterArray;
@property(nonatomic,strong)MBProgressHUD *hud;

@end
@implementation HJDetailThemeViewController
- (void)viewDidLoad {
    [super viewDidLoad];

    self.themeArray = nil;
    
    self.count = 10;
    self.tableView = [[UITableView alloc]initWithFrame:SCREEN_BOUNDS];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    [self.view addSubview:self.tableView];
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
       
        make.left.right.top.bottom.mas_equalTo(0);
    }];
    self.view.backgroundColor = [UIColor whiteColor];
    [self creatRefreshControlAndSendRequest];
}
-(void)creatRefreshControlAndSendRequest{
    MJRefreshNormalHeader *header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(sendRequestToSever)];
    header.lastUpdatedTimeLabel.hidden = NO;
    [header beginRefreshing];
    self.tableView.mj_header = header;
    MJRefreshBackNormalFooter *footer = [MJRefreshBackNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(sendGetMoreData)];
    [footer beginRefreshing];
    self.tableView.mj_footer = footer;
}
-(void)sendRequestToSever{
    NSString *str = [NSString stringWithFormat:@"%@",[NSDate date]];
    NSRange range = {11,8};
    
    NSString *strr1 = [str substringWithRange:range];
    NSString *strr2 = [NSString stringWithFormat:@"%@%@%@",@"%",@"20",strr1];
    
    
    self.urlStr = [NSString stringWithFormat:@"http://www.hjenglish.com/api/api_IOSNews.ashx?op=GetListByTopicWithTime&langs=en&count=%ld&topicID=%@&endTime=%@%@&beginTime=1970-01-01%@",(long)self.count,self.urlStrID,[[NSString stringWithFormat:@"%@",[NSDate date]] substringToIndex:10],strr2,@"%2008:00:00"];    [HJNetworkManager sendGetRequestWithUrl:self.urlStr parameters:nil success:^(id responseObject) {
        self.themeArray = [HJDataManager getAllThemeData:responseObject];
        [self.tableView reloadData];
        [self.tableView.mj_header endRefreshing];
    } failure:^(NSError *error) {
        MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        hud.mode = MBProgressHUDModeText;
        hud.labelText = @"网络错误，请检查您的网络";
        hud.margin = 10;
        [hud hide:YES afterDelay:3];
        [self.tableView.mj_footer endRefreshing];

    }];
}
-(void)sendGetMoreData{
    self.count += 10;
    NSString *str = [NSString stringWithFormat:@"%@",[NSDate date]];
    NSRange range = {11,8};
    
    NSString *strr1 = [str substringWithRange:range];
    NSString *strr2 = [NSString stringWithFormat:@"%@%@%@",@"%",@"20",strr1];
    
    
    self.urlStr = [NSString stringWithFormat:@"http://www.hjenglish.com/api/api_IOSNews.ashx?op=GetListByTopicWithTime&langs=en&count=%ld&topicID=%@&endTime=%@%@&beginTime=1970-01-01%@",(long)self.count,self.urlStrID,[[NSString stringWithFormat:@"%@",[NSDate date]] substringToIndex:10],strr2,@"%2008:00:00"];
    
    [HJNetworkManager sendGetRequestWithUrl:self.urlStr parameters:nil success:^(id responseObject) {
        self.themeArray = [HJDataManager getAllThemeData:responseObject];
        [self.tableView reloadData];
        [self.tableView.mj_footer endRefreshing];
    } failure:^(NSError *error) {
        MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        hud.mode = MBProgressHUDModeText;
        hud.labelText = @"网络错误，请检查您的网络";
        hud.margin = 10;
        [hud hide:YES afterDelay:3];
        [self.tableView.mj_footer endRefreshing];
    }];
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.themeArray.count;
}
- (UITableViewCell  *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
   static NSString *identifier = @"themeCell";
    HJThemeTableViewCell  *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        NSArray *nibs = [[NSBundle mainBundle]loadNibNamed:@"HJThemeTableViewCell" owner:self.tableView options:nil];
        cell = [nibs lastObject];
        cell.theme = self.themeArray[indexPath.row];
    };
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    HJTheme *theme = self.themeArray[indexPath.row];
    theme = self.themeArray[indexPath.row];    
    HJSubDetailViewController *subDetailViewController = [HJSubDetailViewController new];
    subDetailViewController.contentID = theme.ContentID;
    self.hud  = [[MBProgressHUD alloc] initWithView:self.navigationController.view];
    [self.navigationController.view addSubview:self.hud ];
    self.hud .delegate = self;
    [self.hud showWhileExecuting:@selector(myTask) onTarget:self withObject:nil animated:YES];
    [self.navigationController pushViewController:subDetailViewController animated:YES];
}
-(void)myTask{
    sleep(0.9);
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 60;
}

#pragma mark - MBProgressHUDDelegate

- (void)hudWasHidden:(MBProgressHUD *)hud {
    // Remove HUD from screen when the HUD was hidded
    [self.hud removeFromSuperview];
    
    self.hud = nil;
}

@end

//
//  HJSubDetailViewController.h
//  HJ
//
//  Created by tarena6 on 16/2/13.
//  Copyright © 2016年 YH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HJSubDetailViewController : UIViewController
@property(nonatomic,strong)NSNumber *contentID;
@end

//
//  HJSubDetailViewController.m
//  HJ
//
//  Created by tarena6 on 16/2/13.
//  Copyright © 2016年 YH. All rights reserved.
//

#import "HJSubDetailViewController.h"
#import <WebKit/WebKit.h>
#import "Masonry.h"
#import "AFNetworking.h"
#import "HJDetail.h"
#import "HJDataManager.h"
#import "HJNetworkManager.h"
#import "MBProgressHUD.h"

@interface HJSubDetailViewController ()<UIWebViewDelegate>
{

    NSInteger _num;
}
@property(nonatomic,strong)UIWebView *webView;


@end

@implementation HJSubDetailViewController

-(UIWebView *)webView{
    if (!_webView) {
        _webView = [[UIWebView alloc]init];
        _webView.delegate = self;
        _webView.backgroundColor = [UIColor whiteColor];
    }
    return _webView;
}


- (void)viewDidLoad {
    
    [super viewDidLoad];
    _num = 1;
    
    [self.view addSubview:self.webView];
    [self.webView mas_makeConstraints:^(MASConstraintMaker *make) {
      make.left.right.top.bottom.mas_equalTo(0);
    }];
    
    self.view.backgroundColor = [UIColor whiteColor];

    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    
    NSString *urlStr =[NSString stringWithFormat:@"http://www.hjenglish.com/api/api_IOSNews.ashx?op=GetContent&contentID=%@",self.contentID];
    [manager GET:urlStr parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSString *str = responseObject[@"Value"][0][@"Content"];
        NSString *headLabelTest = responseObject[@"Value"][0][@"Title"];
        NSString *timeLabelTest = responseObject[@"Value"][0][@"LastUpdateTime"];
     
       
        NSString *contentStr = [NSString stringWithFormat:@"<html><head> <style type='text/css'> div{font-size:15px;}img{width:300;} </style> </head> <body><h3>%@</h3><h5>%@</h5>%@</html>",headLabelTest,timeLabelTest,str];
         [self.webView loadHTMLString:contentStr baseURL:[NSURL URLWithString:@"okok"]];

    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        hud.mode = MBProgressHUDModeText;
        hud.labelText = @"网络错误，请检查您的网络";
        [hud hide:YES afterDelay:3];

    }];
  }
#pragma mark UIWebViewdelegate


-(BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
    NSLog(@"url %@",request.URL.absoluteString);
    if ([request.URL.absoluteString hasPrefix:@"http"]) {
        [[UIApplication sharedApplication]openURL:request.URL];
        return NO;
    }else
    {
        return YES;
    }
}


@end

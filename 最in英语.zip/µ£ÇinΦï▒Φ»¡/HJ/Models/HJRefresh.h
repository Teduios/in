//
//  HJRefresh.h
//  HJ
//
//  Created by tarena6 on 16/2/14.
//  Copyright © 2016年 YH. All rights reserved.
//

#import <Foundation/Foundation.h>
typedef void(^CompletionHandle) (NSError *error);

@interface HJRefresh : NSObject
@property(nonatomic,strong)NSMutableArray * mutableArray;
@property(nonatomic,strong)NSMutableArray *dataArray;
//获得更多数据
- (void)getMoreDataUrlTitle:(NSString *)urlTitle idAndTag:(NSString *)idAndTag completionHandle:(CompletionHandle)completionHandle;
//刷新数据
- (void)refreshDataUrlTitle:(NSString *)urlTitle idAndTag:(NSString *)idAndTag completionHandle:(CompletionHandle)completionHandle;
//获取或刷新数据
- (void)getDataFromNetUrlTitle:(NSString *)urlTitle idAndTag:(NSString *)idAndTag completionHandle:(CompletionHandle)completionHandle;


@end

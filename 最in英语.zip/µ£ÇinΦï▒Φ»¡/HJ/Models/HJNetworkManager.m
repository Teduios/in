//
//  HJNetworkManager.m
//  HJ
//
//  Created by tarena6 on 16/2/14.
//  Copyright © 2016年 YH. All rights reserved.
//

#import "HJNetworkManager.h"
#import "MBProgressHUD.h"

@implementation HJNetworkManager

+(void)sendGetRequestWithUrl:(NSString *)urlStr parameters:(NSDictionary *)paraDic success:(successBlock)sucess failure:(failureBlock)failure{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    [manager GET:urlStr parameters:paraDic progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        sucess(responseObject);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        HJLog(@"%@",error);
    }];
    
    
}
//GetListByChildCateWithTime  count=20  cateID=1044  2016-02-19
//+ (void) getDataWithUrlTitle:(NSString *)urlTitle count:(NSInteger)count idAndTag:(NSString *)idAndTag dateStr:(NSString *)dateStr sucess:(successBlock) sucess failure:(failureBlock)failure{
//    
//   
//    
//    [self sendGetRequestWithUrl:[NSString stringWithFormat:@"http://www.hjenglish.com/api/api_IOSNews.ashx?op=%@&langs=en&count=20&%@&endTime=%@2013:24:50&beginTime=1970-01-01%2008:00:00",urlTitle,idAndTag,dateStr]parameters:nil success:sucess failure:failure];
//
//
//}


@end

//
//  HJRecommend.m
//  HJ
//
//  Created by tarena6 on 16/2/14.
//  Copyright © 2016年 YH. All rights reserved.
//

#import "HJRecommend.h"

@implementation HJRecommend
/** 此处使用的是kvc的方法，重写此方法后，不用将所有json全部解析，只取需要的即可*/
- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{}

@end

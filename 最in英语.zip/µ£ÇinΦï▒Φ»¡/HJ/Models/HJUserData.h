//
//  HJUserData.h
//  HJ
//
//  Created by tarena6 on 16/2/28.
//  Copyright © 2016年 YH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HJUserData : NSObject
@property(nonatomic,strong)NSString *userName;
@property(nonatomic,strong)NSString *userPassword;
@property(nonatomic,assign) BOOL isLogin;

/**用户数据信息的单例方法*/
+(HJUserData *)sharedUserData;
/**将用户注册名和密码写入数据库*/
+(BOOL)writeLoginMessageToDbuserName :(NSString *)userName userPassword :(NSString *)userPassword;

/**从数据库获取用户登陆信息*/

+(NSArray *)getUserDataFromDb;

@end

//
//  HJDBManager.m
//  HJ
//
//  Created by tarena6 on 16/2/26.
//  Copyright © 2016年 YH. All rights reserved.
//

#import "HJDBManager.h"

@implementation HJDBManager
+ (FMDatabase *)sharedDatabase{
    static FMDatabase *database = nil;
    static dispatch_once_t onceTocken;
    dispatch_once(&onceTocken, ^{
        database = [FMDatabase databaseWithPath:PATH_DB];
    });
    //打开数据库
    [database open];
    return database;
}
@end

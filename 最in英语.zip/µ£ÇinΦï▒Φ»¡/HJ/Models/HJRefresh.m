//
//  HJRefresh.m
//  HJ
//
//  Created by tarena6 on 16/2/14.
//  Copyright © 2016年 YH. All rights reserved.
//

#import "HJRefresh.h"
#import "HJNetworkManager.h"
#import "HJDataManager.h"

@interface HJRefresh()

@property(nonatomic,assign)NSInteger count;

@end
@implementation HJRefresh
-(NSMutableArray *)dataArray{
    if (!_dataArray) {
        _dataArray = [NSMutableArray array];
    }
    return _mutableArray;
}
//
//- (void)getMoreDataUrlTitle:(NSString *)urlTitle idAndTag:(NSString *)idAndTag{
//    self.count +=10;
//    [self getDataFromNetUrlTitle:urlTitle idAndTag:idAndTag];
//}
//
//- (void)refreshDataUrlTitle:(NSString *)urlTitle idAndTag:(NSString *)idAndTag completionHandle:(CompletionHandle)completionHandle{
//    self.count = 20;
//    [self getDataFromNetUrlTitle:urlTitle idAndTag:idAndTag];
//}
//
//- (void)getDataFromNetUrlTitle:(NSString *)urlTitle idAndTag:(NSString *)idAndTag completionHandle:(CompletionHandle)completionHandle{
//     NSString *dateStr = [[NSString stringWithFormat:@"%@",[NSDate date]] substringToIndex:10];
//  
//    [HJNetworkManager getDataWithUrlTitle:urlTitle count:self.count idAndTag:idAndTag  dateStr:dateStr sucess:^(id responseObject) completionHandle:(CompletionHandle)completionHandle{
//        if (self.count == 20) {
//            [self.dataArray removeAllObjects];
//        }
//        NSArray *responseArray = (NSArray *)responseObject;
//        [self.dataArray addObjectsFromArray:responseArray];
//    } failure:^(NSError *error) {
//        HJLog(@"%@",error.userInfo);
//    }];
//}
//加载更多数据
- (void) getMoreDataUrlTitle:(NSString *)urlTitle idAndTag:(NSString *)idAndTag completionHandle:(CompletionHandle)completionHandle{
    self.count +=10;
    [self getDataFromNetUrlTitle:urlTitle idAndTag:idAndTag completionHandle:completionHandle];

}
//刷新数据
- (void) refreshDataUrlTitle:(NSString *)urlTitle idAndTag:(NSString *)idAndTag completionHandle:(CompletionHandle)completionHandle{
    self.count = 20;
    [self getDataFromNetUrlTitle:urlTitle idAndTag:idAndTag completionHandle:completionHandle];
}
//获取数据
- (void) getDataFromNetUrlTitle:(NSString *)urlTitle idAndTag:(NSString *)idAndTag completionHandle:(CompletionHandle)completionHandle{
    NSString *dateStr = [[NSString stringWithFormat:@"%@",[NSDate date]] substringToIndex:10];
    
    [HJNetworkManager getDataWithUrlTitle:urlTitle count:self.count idAndTag:idAndTag dateStr:dateStr sucess:^(id responseObject) {
        if (self.count == 20) {
            [self.dataArray removeAllObjects];
        }
        NSArray *responseArray = (NSArray *)responseObject;
        [self.dataArray addObjectsFromArray:responseArray];
        
        completionHandle(nil);
       
    } failure:^(NSError *error) {
        
    }];


}
@end

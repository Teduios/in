//
//  HJUserData.m
//  HJ
//
//  Created by tarena6 on 16/2/28.
//  Copyright © 2016年 YH. All rights reserved.
//

#import "HJUserData.h"
#import "FMDatabase.h"
#import "HJDBManager.h"
#import "HJDataTheme.h"

@implementation HJUserData
static HJUserData * userData = nil;
+(HJUserData *)sharedUserData{
    if (!userData) {
        userData = [[HJUserData alloc]init];
    }
    return userData;
}


/**将用户注册名和密码写入数据库*/

+(BOOL)writeLoginMessageToDbuserName :(NSString *)userName userPassword :(NSString *)userPassword{
    FMDatabase *database = [HJDBManager sharedDatabase];
    BOOL success = YES;
    if ([database open]) {
        NSString *str = [NSString stringWithFormat:@"insert into HJ_USER (username,userpassword) values ('%@','%@')",userName,userPassword];
        //NSString *str = [NSString stringWithFormat:@"insert into HJ_USER (username,userpassword) values ('%@','%@')",@"name",@"word"];
         BOOL success = [database executeUpdate:str];
        if (success) {
            HJLog(@"我成功了");
        }
        HJLog(@"数据库开着呢");
    }else{
        HJLog(@"数据库没开");
        success = NO;
    }
    NSString *queryStr = @"select *from HJ_USER";
    FMResultSet *resultSet = [database executeQuery:queryStr];

    while ([resultSet next]) {
        HJLog(@"%@==%@",[resultSet stringForColumn:@"username"],[resultSet stringForColumn:@"userpassword"]);
    }
   
    [database close];
    return success;
}

+(NSArray *)getUserDataFromDb{
    FMDatabase *database = [HJDBManager sharedDatabase];
    FMResultSet *resultSet = [database executeQuery:@"select *from HJ_USER"];
    NSMutableArray *mutableArray = [NSMutableArray array];

    while ([resultSet next]) {
        HJUserData *userData = [HJUserData new];
        userData.userName = [resultSet stringForColumn:@"username"];
        userData.userPassword = [resultSet stringForColumn:@"userpassword"];
        [mutableArray addObject:userData];
    }
    [database closeOpenResultSets];
    [database close];
    
    return [mutableArray copy];
}

@end

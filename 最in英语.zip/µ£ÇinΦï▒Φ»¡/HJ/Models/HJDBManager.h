//
//  HJDBManager.h
//  HJ
//
//  Created by tarena6 on 16/2/26.
//  Copyright © 2016年 YH. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDatabase.h"
#define PATH_DB [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject stringByAppendingPathComponent:@"HJTheme.db"]
@interface HJDBManager : NSObject
/**单例模式，返回唯一数据库对象*/

+ (FMDatabase *)sharedDatabase;

@end

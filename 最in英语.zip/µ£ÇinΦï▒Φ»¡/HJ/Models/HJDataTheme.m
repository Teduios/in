//
//  HJDataTheme.m
//  HJ
//
//  Created by tarena6 on 16/2/26.
//  Copyright © 2016年 YH. All rights reserved.
//

#import "HJDataTheme.h"
#import "FMDatabase.h"
#import "HJDBManager.h"

@implementation HJDataTheme

+(NSArray *)themestableName:(NSString*)tableName{
//+(NSArray *)themes{
 /**
  从数据库中获取所有HJ_ARTICLE数据
  */
    FMDatabase *database = [HJDBManager sharedDatabase];
    NSString *string = [NSString stringWithFormat:@"select * from %@",tableName];
   FMResultSet *resultSet = [database executeQuery:string];
    
    NSMutableArray *mutableArray = [NSMutableArray array];
    while ([resultSet next]) {
        HJDataTheme *theme = [HJDataTheme new];
        theme.headline = [resultSet stringForColumn:@"headline"];
        theme.doublelanguage = [resultSet stringForColumn:@"doublelanguage"];
        theme.english = [resultSet stringForColumn:@"english"];
        theme.chinese = [resultSet stringForColumn:@"chinese"];
        
        [mutableArray addObject:theme];
    }
    //释放掉搜索出来的内容
    [database closeOpenResultSets];
    //关闭数据库
    [database close];
    
    return [mutableArray copy];
}


@end

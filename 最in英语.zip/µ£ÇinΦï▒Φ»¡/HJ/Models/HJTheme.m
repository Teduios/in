//
//  HJTheme.m
//  HJ
//
//  Created by tarena6 on 16/2/21.
//  Copyright © 2016年 YH. All rights reserved.
//

#import "HJTheme.h"

@implementation HJTheme
-(void)setValue:(id)value forUndefinedKey:(NSString *)key{

}
@end

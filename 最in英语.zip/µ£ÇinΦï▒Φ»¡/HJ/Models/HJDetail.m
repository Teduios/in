//
//  HJDetail.m
//  HJ
//
//  Created by tarena6 on 16/2/17.
//  Copyright © 2016年 YH. All rights reserved.
//

#import "HJDetail.h"

@implementation HJDetail
-(void)setValue:(id)value forUndefinedKey:(NSString *)key{

}
@end

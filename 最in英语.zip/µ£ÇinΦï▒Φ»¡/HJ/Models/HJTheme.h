//
//  HJTheme.h
//  HJ
//
//  Created by tarena6 on 16/2/21.
//  Copyright © 2016年 YH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HJTheme : NSObject
@property(nonatomic,assign)NSNumber *ContentID;
@property(nonatomic,strong)NSString *Title;
@property(nonatomic,strong)NSString *AutoSummary;
@end

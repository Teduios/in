//
//  HJRecommend.h
//  HJ
//
//  Created by tarena6 on 16/2/14.
//  Copyright © 2016年 YH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HJRecommend : NSObject
@property(nonatomic,assign)NSNumber *ContentID;
@property(nonatomic,strong)NSString *Title;
@property(nonatomic,strong)NSString *IconUrl;
@property(nonatomic,strong)NSString *AutoSummary;



@end

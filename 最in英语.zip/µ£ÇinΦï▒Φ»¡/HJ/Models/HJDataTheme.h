//
//  HJDataTheme.h
//  HJ
//
//  Created by tarena6 on 16/2/26.
//  Copyright © 2016年 YH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HJDataTheme : NSObject
@property(nonatomic,strong)NSString *headline;
@property(nonatomic,strong)NSString *doublelanguage;
@property(nonatomic,strong)NSString *english;
@property(nonatomic,strong)NSString *chinese;

//从数据库中读取内容，宝盒界面
+(NSArray *)themestableName:(NSString*)tableName;


@end

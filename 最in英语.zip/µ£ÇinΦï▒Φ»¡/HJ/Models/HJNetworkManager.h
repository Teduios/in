//
//  HJNetworkManager.h
//  HJ
//
//  Created by tarena6 on 16/2/14.
//  Copyright © 2016年 YH. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AFNetworking.h"
typedef void(^successBlock)(id responseObject);
typedef void(^failureBlock)(NSError *error);
@interface HJNetworkManager : NSObject
+ (void)sendGetRequestWithUrl:(NSString *)urlStr parameters:(NSDictionary *)paraDic success:(successBlock)sucess failure:(failureBlock)failure;

+ (void) getDataWithUrlTitle:(NSString *)urlTitle count:(NSInteger)count idAndTag:(NSString *)idAndTag dateStr:(NSString *)dateStr sucess:(successBlock) sucess failure:(failureBlock)failure;
    

@end

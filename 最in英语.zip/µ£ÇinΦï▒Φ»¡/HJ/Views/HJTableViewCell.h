//
//  HJTableViewCell.h
//  HJ
//
//  Created by tarena6 on 16/2/18.
//  Copyright © 2016年 YH. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HJRecommend.h"

@interface HJTableViewCell : UITableViewCell
@property(nonatomic,strong)HJRecommend *recommend;
@end

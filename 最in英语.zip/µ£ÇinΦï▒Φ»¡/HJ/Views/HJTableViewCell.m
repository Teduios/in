//
//  HJTableViewCell.m
//  HJ
//
//  Created by tarena6 on 16/2/18.
//  Copyright © 2016年 YH. All rights reserved.
//

#import "HJTableViewCell.h"
#import "UIImageView+WebCache.h"

@interface HJTableViewCell()




@property (weak, nonatomic) IBOutlet UIImageView *headImageView;
@property (weak, nonatomic) IBOutlet UILabel *themeLabel;
@property (weak, nonatomic) IBOutlet UILabel *detailLabel;
@end
@implementation HJTableViewCell

-(void)setRecommend:(HJRecommend *)recommend{
    _recommend = recommend;
    [self.headImageView sd_setImageWithURL:[NSURL URLWithString:self.recommend.IconUrl] placeholderImage:[UIImage imageNamed:@"topicImageInCell2"]];
    self.themeLabel.text = self.recommend.Title;
    self.detailLabel.text = self.recommend.AutoSummary;
   
}
@end

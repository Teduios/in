//
//  HJBoxCollectionViewCell.m
//  HJ
//
//  Created by tarena6 on 16/2/12.
//  Copyright © 2016年 YH. All rights reserved.
//

#import "HJBoxCollectionViewCell.h"

@implementation HJBoxCollectionViewCell

- (void)awakeFromNib {
    // Initialization code
}


@end

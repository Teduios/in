//
//  HJBoxDetailTableViewCell.m
//  HJ
//
//  Created by tarena6 on 16/2/26.
//  Copyright © 2016年 YH. All rights reserved.
//

#import "HJBoxDetailTableViewCell.h"

@implementation HJBoxDetailTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

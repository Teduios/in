//
//  HJBoxDetailTableViewCell.h
//  HJ
//
//  Created by tarena6 on 16/2/26.
//  Copyright © 2016年 YH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HJBoxDetailTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *headlineLabel;
@property (weak, nonatomic) IBOutlet UIImageView *headImageView;
@property (weak, nonatomic) IBOutlet UILabel *contentLabel;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *labelHeightConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *headLabelConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *imageViewConstraint;




@end

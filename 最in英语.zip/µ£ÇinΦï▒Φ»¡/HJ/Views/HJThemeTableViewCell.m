//
//  HJThemeTableViewCell.m
//  HJ
//
//  Created by tarena6 on 16/2/21.
//  Copyright © 2016年 YH. All rights reserved.
//

#import "HJThemeTableViewCell.h"
@interface HJThemeTableViewCell()

@property (weak, nonatomic) IBOutlet UILabel *NameLabel;
@property (weak, nonatomic) IBOutlet UILabel *ContentLabel;
@property(nonatomic,strong) UILabel *nameL;
@end

@implementation HJThemeTableViewCell

-(void)setTheme:(HJTheme *)theme{
    _theme = theme;
    self.NameLabel.text = theme.Title;
    self.ContentLabel.text = theme.AutoSummary;
    

}



@end

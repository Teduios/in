//
//  HJThemeTableViewCell.h
//  HJ
//
//  Created by tarena6 on 16/2/21.
//  Copyright © 2016年 YH. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HJTheme.h"

@interface HJThemeTableViewCell : UITableViewCell
@property(nonatomic,strong)HJTheme *theme;
@end
